* always use the full path to the file that is shown when you list all files
* only .txt files will be listed
* shared folders can be created once multiple users were created
* folders won't be shown when listing files if they are empty but they were still created and can be selected when putting a file in the secure storage
* every user has their own password
* every created folder has its own password
* on user creation a folder with the same name will be created and used as the standard storage for this user (cannot be shared)